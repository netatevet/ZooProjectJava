package privateutil;

import animals.Animal;
import diet.Carnivore;
import food.EFoodType;
import food.IEdible;
import mobility.Point;

public abstract class EatingClass extends Animal {
	
	public EatingClass(String name, Point location) {
		super(name, location);
		// TODO Auto-generated constructor stub
	}

	public double eat(Animal animal, IEdible food) {
		
		if(food.getFoodType() == EFoodType.MEAT) {
			return animal.getWeight()*0.1;
		}
		if(food.getFoodType() == EFoodType.VEGETABLE) {
			return animal.getWeight()*0.07;
		}
		
		return 0;
			
		
	}

}
