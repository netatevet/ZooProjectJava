package diet;

import animals.Animal;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import privateutil.EatingClass;
import utilities.MessageUtility;

/**
 * A class that describes a carnivore - animal that eat only meat.
 * 
 *
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Lion
 */
public abstract class Carnivore extends Animal implements IDiet {
	/**
	 * Carnivore's constructor.
	 * 
	 * @param name - carnivore's name.
	 * @param location - carnivore's location.
	 */
	public Carnivore(String name, Point location) {
		super(name, location);
	}
	
	@Override
	public boolean canEat(EFoodType food) {
		if(food == EFoodType.MEAT)
			return true;
		return false;
		
	}
	
	public Carnivore(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		super(size,col,h,v,zooPanel,type);
	}
	
	@Override
	
	public double eat(Animal animal, IEdible food) {
		if(animal instanceof Carnivore) {
			if(((Carnivore)animal).canEat(food.getFoodType())) {
				return animal.getWeight()*0.1;
			}
		}
		return 0;
		
	}
	
	//@Override
	//public double eat(Animal animal, IEdible food) {
		//if(((Carnivore)animal).canEat(food.getFoodType())){
			//super.eat(animal, food);
		//}
		
		//return 0;
	//}
	
	@Override
	public boolean eat(IEdible food) {
		 double gained=this.eat(this,food);
		 boolean isSuccess = false;
		 if(gained > 0) { isSuccess = true; }
		 MessageUtility.logBooleanFunction(this.getName(), "eat", food.getFoodType(), isSuccess);
		 return this.afterEat(gained);
		 
	}

}
