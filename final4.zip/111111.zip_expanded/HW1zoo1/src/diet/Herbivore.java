package diet;

import animals.Animal;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import privateutil.EatingClass;
import utilities.MessageUtility;

/**
 * A class that describes a herbivore - animal that eat only vegetables.
 * 
 *
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Elephant,Giraffe,Turtle
 */
public abstract class Herbivore extends Animal implements IDiet {
	/**
	 * Herbivore's constructor.
	 * @param name - herbivore's name.
	 * @param location herbivore's location.
	 */
	public Herbivore(String name, Point location) {
		super(name, location);
	}
	
	public Herbivore(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		super(size,col,h,v,zooPanel,type);
	}
	
	@Override
	public boolean canEat(EFoodType food) {
		if(food == EFoodType.VEGETABLE)
			return true;
		return false;
		
	}
	
	@Override
    public double eat(Animal animal,IEdible food) {
		if(animal instanceof Herbivore) {
			if(((Herbivore)animal).canEat(food.getFoodType())) {
				return animal.getWeight()*0.07;
			}
		}
		return 0;
	}
	
	//@Override
	//public double eat(Animal animal, IEdible food) {
	//	if(((Herbivore)animal).canEat(food.getFoodType())){
	//		super.eat(animal, food);
	//	}
		
	//	return 0;
	//}
	
	@Override
	public boolean eat(IEdible food) {
		 double gained=this.eat(this,food);
		 boolean isSuccess = gained > 0;
		 MessageUtility.logBooleanFunction(this.getName(), "eat", food.getFoodType(), isSuccess);
		 return this.afterEat(gained);
	}

}
