package diet;

import animals.Animal;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import privateutil.EatingClass;
import utilities.MessageUtility;

/**
 * A class that describes a omnivore - animal that eat all.
 * 
 *
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Bear
 */
public abstract class Omnivore extends Animal implements IDiet {
	/**
	 * Omnivore's constructor.
	 * @param name - omnivore's name.
	 * @param location - omnivore's location.
	 */
	public Omnivore(String name, Point location) {
		super(name, location);
	}
	
	public Omnivore(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		super(size,col,h,v, zooPanel,type);
	}
	
	@Override
	public boolean canEat(EFoodType food) {
		if(food == EFoodType.NOTFOOD)
			return false;
		return true;
		
	}
	
	@Override
	public double eat(Animal animal,IEdible food) {
		if(animal instanceof Omnivore) {
			if(food.getFoodType() == EFoodType.MEAT)
				return animal.getWeight()*0.1;
			else if(food.getFoodType() == EFoodType.VEGETABLE)
				return animal.getWeight()*0.07;
			
		}
		return 0;
	}
	
	//@Override
	//public double eat(Animal animal, IEdible food) {
		//if(((Omnivore)animal).canEat(food.getFoodType())){
			//super.eat(animal, food);
		//}
		
		//return 0;
	//}
	@Override
	public boolean eat(IEdible food) {
		 double gained=this.eat(this,food);
		 boolean isSuccess = gained > 0;
		 MessageUtility.logBooleanFunction(this.getName(), "eat", food.getFoodType(), isSuccess);
		 return this.afterEat(gained);
	}

}
