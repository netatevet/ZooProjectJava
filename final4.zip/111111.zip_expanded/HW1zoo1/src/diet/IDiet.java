package diet;

import animals.Animal;
import food.EFoodType;
import food.IEdible;
/**
 * An interface that describes the functionality of eating. 
 * 
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Carnivore,Omnivore,Herbivore
 *
 */
public interface IDiet {
	/**
	 * Checks if the object can eat the parameter food.
	 * 
	 * @param food - the object that the object that called the method want to eat.
	 * @return true - if the object can eat the food.
	 *         false- if does'nt.
	 */
	public boolean canEat(EFoodType food);
	/**
	 * 
	 * 
	 * @param animal-the object that will eat the food.
	 * @param food-the object that will be eaten.
	 * @return the weight that the animal that eat will gain. 
	 */
	public double eat(Animal animal,IEdible food);

}
