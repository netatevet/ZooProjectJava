module HW1zoo {
	requires java.desktop;
}