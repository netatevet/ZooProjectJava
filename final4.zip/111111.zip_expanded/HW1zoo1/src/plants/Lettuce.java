package plants;

import graphics.MenuItemListener;
import utilities.MessageUtility;

/**
 * @author baroh
 *
 */
public class Lettuce extends Plant {
	
	private static Lettuce instance = null;

	
	public Lettuce() {
		MessageUtility.logConstractor("Lettuce", "Lettuce");
	    this.setImg("lettuce");

	}
	
	public static Lettuce getInstance() { 
		if(instance == null) { 
			instance = new Lettuce(); 
		} 
		return instance; 
	} 
}
