package plants;

import food.EFoodType;

public class Meat extends Plant {
	
	private static Meat instance = null;

	
	public Meat() {
	    this.setImg("meat");

	}
	
	public static Meat getInstance() { 
		if(instance == null) { 
			instance = new Meat(); 
		} 
		return instance; 
	} 
	
	
	
	public EFoodType getFoodType() {
		return EFoodType.MEAT;
	};

}
