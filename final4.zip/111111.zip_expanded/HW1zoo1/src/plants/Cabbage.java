package plants;

import graphics.MenuItemListener;
import graphics.ZooPanel;
import utilities.MessageUtility;

/**
 * @author baroh
 *
 */
public class Cabbage extends Plant {
	private static Cabbage instance = null;
	
	public Cabbage() {
		MessageUtility.logConstractor("Cabbage", "Cabbage");
	    this.setImg("cabbage");

	}
	public static Cabbage getInstance(MenuItemListener menuItemListener) { 
		if(instance == null) { 
			instance = new Cabbage(); 
		} 
		return instance; 
	} 

}
