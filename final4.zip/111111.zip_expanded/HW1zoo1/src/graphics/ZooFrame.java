package graphics;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSplitPane;


/**
 *A class that represents zoo frame.
 * @version 1.0 2 May 2022
 * @author  Rita Vinitsky&Neta Mishael Tevet
 *
 */
public class ZooFrame extends JFrame{
	
	JMenuBar menuBar;
	JMenu fileMenu;
	JMenu backgroundMenu;
	JMenu helpMenu;
	ZooPanel zooPanel;
	JMenuItem exitItem;
	JMenuItem imageItem;
	JMenuItem greenItem;
	JMenuItem noneItem;
	JMenuItem helpItem;
	//JLabel savanna;
	
	
	/**
	 * ZooFrame's constructor.
	 * 
	 * @param title - the title that will appear on the frame.
	 */
	ZooFrame(String title){
		super(title);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null);
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setSize(800, 600);
		MenuItemListener menuItemListener = new MenuItemListener();
		//savanna = new JLabel();
		//savanna.setIcon(new ImageIcon("C:\\Users\\Neta6\\Desktop\\hw2pic\\savanna.png"));
		//this.add(savanna);
		this.menuBar = new JMenuBar();
		this.fileMenu = new JMenu("File");
		this.backgroundMenu = new JMenu("Background");
		this.helpMenu = new JMenu("Help");
		//this.zooPanel = new ZooPanel(menuItemListener);
		this.zooPanel = ZooPanel.getInstance(menuItemListener);
		menuItemListener.setFrame(this);
		menuItemListener.setPanel(this.zooPanel);
        this.exitItem = new JMenuItem("Exit");
		this.exitItem.setActionCommand("Exit");
		this.exitItem.addActionListener(menuItemListener);
		this.fileMenu.add(exitItem);
		this.imageItem = new JMenuItem("Image");
		this.imageItem.setActionCommand("Image");
		this.imageItem.addActionListener(menuItemListener);
		this.backgroundMenu.add(imageItem);
		this.greenItem = new JMenuItem("Green");
		this.greenItem.setActionCommand("Green");
		this.greenItem.addActionListener(menuItemListener);
		this.backgroundMenu.add(greenItem);
		this.noneItem = new JMenuItem("None");
		this.noneItem.setActionCommand("None");
		this.noneItem.addActionListener(menuItemListener);
		this.backgroundMenu.add(noneItem);
		this.helpItem = new JMenuItem("Help");
		this.helpItem.setActionCommand("Help");
		this.helpItem.addActionListener(menuItemListener);
		this.helpMenu.add(helpItem);
		this.menuBar.add(fileMenu);
		this.menuBar.add(backgroundMenu);
		this.menuBar.add(helpMenu);
		//menuItemListener.setPanel(zooPanel);
		
		BorderLayout myBorderLayout = new BorderLayout();
		this.setLayout(myBorderLayout);

		this.add(zooPanel);
        this.setJMenuBar(menuBar);
		
		
		
		this.setVisible(true);
		
	}
	
	/**
	 * the main function.
	 * 
	 * @param args
	 */
	
	
	public static void main(String [] args) {
		//MenuItemListener menuItemListener = new MenuItemListener();
		ZooFrame zooFrame = new ZooFrame("Zoo");
		
		
		
	}
	
	
	
	/*
	public static void main(String [] args) {
		JFrame frame = new JFrame("Zoo");
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		JMenuBar menuBar = new JMenuBar();
		
		JMenu fileMenu = new JMenu("File");
		JMenu backgroundMenu = new JMenu("Background");
		JMenu helpMenu = new JMenu("Help");
		
		ZooPanel zooPanel = new ZooPanel();
		//zooPanel.setLocation(10, 10);

		//zooPanel.setBounds(0, 0, 250, 250);
		
		MenuItemListener menuItemListener = new MenuItemListener();
		menuItemListener.setFrame(frame);
		menuItemListener.setPanel(zooPanel);
		
		JMenuItem exitItem = new JMenuItem("Exit");
		exitItem.setActionCommand("Exit");
		exitItem.addActionListener(menuItemListener);
		fileMenu.add(exitItem);
		JMenuItem imageItem = new JMenuItem("Image");
		imageItem.setActionCommand("Image");
		imageItem.addActionListener(menuItemListener);
		backgroundMenu.add(imageItem);
		JMenuItem greenItem = new JMenuItem("Green");
		greenItem.setActionCommand("Green");
		greenItem.addActionListener(menuItemListener);
		backgroundMenu.add(greenItem);
		JMenuItem noneItem = new JMenuItem("None");
		noneItem.setActionCommand("None");
		noneItem.addActionListener(menuItemListener);
		backgroundMenu.add(noneItem);
		JMenuItem helpItem = new JMenuItem("Help");
		helpItem.setActionCommand("Help");
		helpItem.addActionListener(menuItemListener);
		helpMenu.add(helpItem);
		

		menuBar.add(fileMenu);
		menuBar.add(backgroundMenu);
		menuBar.add(helpMenu);
		/*
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(Color.blue);
		buttonPanel.setLocation(0, 0);
		buttonPanel.setBounds(0, 250, 500, 250);
		
		JButton addButton = new JButton("Add");
		addButton.setActionCommand("Add");
		addButton.addActionListener(menuItemListener);
		JButton moveBotton = new JButton("Move");
		moveBotton.setActionCommand("Move");
		moveBotton.addActionListener(menuItemListener);
		JButton clearBotton = new JButton("Clear");
		clearBotton.setActionCommand("Clear");
		clearBotton.addActionListener(menuItemListener);
		JButton foodBotton = new JButton("Food");
		foodBotton.setActionCommand("Food");
		foodBotton.addActionListener(menuItemListener);
		JButton infoBotton = new JButton("Info");
		infoBotton.setActionCommand("Info");
		infoBotton.addActionListener(menuItemListener);
		JButton exitBotton = new JButton("Exit");
		exitBotton.setActionCommand("Exit2");
		exitBotton.addActionListener(menuItemListener);
		*/
		/*
		menuItemListener.setPanel(zooPanel);
	
		BorderLayout myBorderLayout = new BorderLayout();
		frame.setLayout(myBorderLayout);
		
/*
		buttonPanel.add(addButton);
		buttonPanel.add(moveBotton);
		buttonPanel.add(clearBotton);
		buttonPanel.add(foodBotton);
		buttonPanel.add(infoBotton);
		buttonPanel.add(exitBotton);
		*/
	/*
		frame.add(zooPanel,BorderLayout.SOUTH);
		//frame.add(buttonPanel,BorderLayout.SOUTH);
		

		
		//frame.add(buttonPanel);
		
		frame.setJMenuBar(menuBar);
		
		
		
		frame.setVisible(true);
		
		*/
	}
	
	

