package graphics;

import java.awt.Graphics;

/**
 * An interface that describes the functionality of drawing images. 
 * 
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Animal,Plant
 *
 */
public interface IDrawable {

		public final static String PICTURE_PATH = "C:\\Users\\Neta6\\Desktop\\hw2pic";
		
		/**
		 * Loads object's image.
		 * 
		 * @param nm - the start of the name of the image file.
		 */
		public void loadImages(String nm);
		
		/**
		 * Draws image.
		 * 
		 * @param g - Graphics object.
		 */
		public void drawObject (Graphics g);
		
		/**
		 * Color getter.
		 *
		 *@return object's color.
		 */
		public String getColor();

}
