package graphics;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *A class that represents move animal in the zoo dialog.
 * @version 1.0 2 May 2022
 * @author  Rita Vinitsky&Neta Mishael Tevet
 *
 */
public class MoveAnimalDialog extends JDialog {
	MenuItemListener menuItemListener;
	static JComboBox c1;
	static JLabel l, l1;
	private final JTextField tbX;
    private final JTextField tbY;
    ArrayList<String> s2;
    String names[];
    JButton confirmButton;
    String selected;
    int x,y;
    
    
    /**
	 * MoveAnimalDialog's constructor.
	 * 
	 * @param window - the window that opens the dialog.
	 * @param menuItemListener - the menuItemListener that manages the commands.
     * @param s - array of the names of the animals that exist in the zoo.
	 */
    MoveAnimalDialog(JFrame window,MenuItemListener menuItemListener,ArrayList<String> s){

        super(window, "Move Animal", true);
        this.menuItemListener = menuItemListener;
        this.s2 = s;
        this.names=new String[s.size()];
        
        for(int i=0; i<s.size(); i++)
        {
        	this.names[i]=this.s2.get(i);
        }
       // MenuItemListener menuItemListener = new MenuItemListener();
       // menuItemListener.setMoveAnimalDialog(this);
        this.setLayout(new FlowLayout());
        this.setSize(400, 300);
		//this.s = new ArrayList<string>();

       // String s1[]=this.s.toArray(new String[0]);
        String s1[] = {};
        c1 = new JComboBox(names);
        l = new JLabel("select animal ");
        l1 = new JLabel("selected");
        JPanel p = new JPanel();
        p.add(l);
        p.add(c1);
        p.add(l1);
        this.add(p);
        
        
 
        this.setLayout(new GridLayout(0, 1));
        this.add(new JLabel("x: "));
        this.add(tbX = new JTextField());
        
        JPanel errorPanel = new JPanel();
        JLabel errorLabel = new JLabel("wrong size");
        errorLabel.setForeground(Color.red);
        errorLabel.setVisible(false);
        this.add(errorLabel);
        
        this.setLayout(new GridLayout(0, 1));
        this.add(new JLabel("y: "));
        this.add(tbY = new JTextField());
       
        
        JPanel errorPanel2 = new JPanel();
        JLabel errorLabel2 = new JLabel("wrong size");
        errorLabel2.setForeground(Color.red);
        errorLabel2.setVisible(false);
        this.add(errorLabel2);
        
        
        
        
        
        
        menuItemListener.setMoveAnimalDialog(this, c1, tbX , tbY ,errorLabel, errorLabel2);
        confirmButton = new JButton("Confirm");
        confirmButton.setActionCommand("Confirm2");
		confirmButton.addActionListener(menuItemListener);
		this.add(confirmButton);
		
		
		 this.setVisible(true);
    }

}
