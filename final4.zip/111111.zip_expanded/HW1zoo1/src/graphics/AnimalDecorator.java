package graphics;

import animals.Animal;

public  class AnimalDecorator implements IChangeColor {
	
	protected Animal newcolorAnimal;
	
	public AnimalDecorator(Animal newcolorAnimal) {
		this.newcolorAnimal = newcolorAnimal;
		
	}
	
	public void changeColor(String color) {
	 newcolorAnimal.changeColor(color);
	}

}
