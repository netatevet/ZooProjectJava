package graphics;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AddDietAnimalDialog extends JDialog {
	MenuItemListener menuItemListener;
	static JLabel l;
	JButton CarnivoreButton;
	JButton OmnivoreButton;
	JButton HerbivoreButton;

	 /**
   	 * FoodAnimalDialog's constructor.
   	 * 
   	 * @param window - the window that opens the dialog.
   	 * @param menuItemListener - the menuItemListener that manages the commands.
   	 */
	AddDietAnimalDialog(JFrame window,MenuItemListener menuItemListener){
        super(window, "Add Animal", true);
    	this.menuItemListener = menuItemListener;

        //MenuItemListener menuItemListener = new MenuItemListener();
        this.setSize(400, 300);
        l = new JLabel("Please choose animal's diet ");
        this.add(l);
      
        JPanel buttonPanel = new JPanel();
        CarnivoreButton = new JButton("Carnivore");
        CarnivoreButton.setActionCommand("Carnivore");
        CarnivoreButton.addActionListener(menuItemListener);
        OmnivoreButton = new JButton("Omnivore");
        OmnivoreButton.setActionCommand("Omnivore");
        OmnivoreButton.addActionListener(menuItemListener);
        HerbivoreButton = new JButton("Herbivore");
        HerbivoreButton.setActionCommand("Herbivore");
        HerbivoreButton.addActionListener(menuItemListener);
        buttonPanel.add(l);
        buttonPanel.add(CarnivoreButton);
		buttonPanel.add(OmnivoreButton);
		buttonPanel.add(HerbivoreButton);
		
		this.add(buttonPanel);
		menuItemListener.setAddDietAnimalDialog(this);
		this.setVisible(true);

	}

}
