package graphics;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import animals.Bear;
import animals.Elephant;
import animals.Giraffe;
import animals.Lion;
import animals.Turtle;


/**
 *A class that represents add animal to the zoo dialog.
 * @version 1.0 2 May 2022
 * @author  Rita Vinitsky&Neta Mishael Tevet
 *
 */
public class AddAnimalDialog extends JDialog  {
	
	MenuItemListener menuItemListener;
	static JComboBox c1,c2,c3,c4,c5;
	static JLabel l, l1,m,m1,n,n1,o,o1,k,k1;
	String selected,col;
	int size,hspeed,vspeed;
	JButton confirmButton;
    JTextField tbSize;
    
    
    /**
   	 * AddAnimalDialog's constructor.
   	 * 
   	 * @param window - the window that opens the dialog.
   	 * @param menuItemListener - the menuItemListener that manages the commands.
   	 */
    AddAnimalDialog(JFrame window, MenuItemListener menuItemListener,String option)
    {
    	super(window, "Add Animal", true);
    	
    	this.menuItemListener = menuItemListener;
        
        this.setLayout(new FlowLayout());
        this.setSize(400, 300);
       // String s1[] = { "Carnivore", "Omnivore", "Herbivore" };
        String car[] = {"Lion"};
        String omn[] = {"Bear"};
        String her[] = {"Giraffe","Turtle","Elephant"};
        if(option == "Carnivore")
        {
        c1 = new JComboBox<String>(car);
        }
        if(option == "Herbivore")
        {
            c1 = new JComboBox<String>(her);

        }
        if(option == "Omnivore")
        {
            c1 = new JComboBox<String>(omn);

        }
        l = new JLabel("select type ");
        l1 = new JLabel("selected");
        
        
        JPanel p = new JPanel();

        p.add(l);
 
        // add combobox to panel
        p.add(c1);
 
        p.add(l1);
 
        // add panel to frame
        this.add(p);
       
        
        
 
        this.setLayout(new GridLayout(0, 1));
        this.add(new JLabel("Size: "));
        tbSize = new JTextField();
        this.add(tbSize);
       
        
        JPanel errorPanel = new JPanel();
        JLabel errorLabel = new JLabel("wrong size");
        errorLabel.setForeground(Color.red);
        errorLabel.setVisible(false);
        this.add(errorLabel);
       
        /*
        this.setLayout(new GridLayout(0, 1));
        this.add(new JLabel("Horizontal speed: "));
        this.add(tbHspeed = new JTextField());
        
        this.setLayout(new GridLayout(0, 1));
        this.add(new JLabel("Vertical speed: "));
        this.add(tbVspeed = new JTextField());
        */
        String s2[] = { "Natural", "Red", "Blue" };
        c2 = new JComboBox(s2);
        m = new JLabel("select color ");
        m1 = new JLabel("selected");
        
        JPanel p2 = new JPanel();

        p2.add(m);
 
        // add combobox to panel
        p2.add(c2);
 
        p2.add(m1);
 
        // add panel to frame
        this.add(p2);
        
        String s3[] = { "1", "2", "3", "4", "5","6","7","8","9","10" };
        c3 = new JComboBox(s3);
        n = new JLabel("Horizontal speed ");
        n1 = new JLabel("selected");
        
        JPanel p3 = new JPanel();

        p3.add(n);
 
        // add combobox to panel
        p3.add(c3);
 
        p3.add(n1);
 
        // add panel to frame
        this.add(p3);
        
        c4 = new JComboBox(s3);
        o = new JLabel("Vertical speed ");
        o1 = new JLabel("selected");
       
        JPanel p4 = new JPanel();

        p4.add(o);
 
        // add combobox to panel
        p4.add(c4);
 
        p4.add(o1);
 
        // add panel to frame
        this.add(p4);
        
        
        menuItemListener.setAddAnimalDialog(this, c1, tbSize , c2 , c3 , c4, errorLabel);
        
        confirmButton = new JButton("Confirm");
        confirmButton.setActionCommand("Confirm");
		confirmButton.addActionListener(menuItemListener);
		this.add(confirmButton);
		
       
        this.setVisible(true);
        
        /*
        if(this.selected == "Lion") {
        	Lion lion = new Lion(size,col,hspeed,vspeed);
        }
        else if (this.selected == "Bear") {
        	Bear bear = new Bear(size,col,hspeed,vspeed);
        }
        else if (this.selected == "Elephant") {
        	Elephant elephant = new Elephant(size,col,hspeed,vspeed);
        }
        else if (this.selected == "Giraffe") {
        	Giraffe giraffe = new Giraffe(size,col,hspeed,vspeed);
        }
        else if (this.selected == "Turtle") {
        	Turtle turtle = new Turtle(size,col,hspeed,vspeed);
        }
      */
        
        	
        }
    
    
   
    }



