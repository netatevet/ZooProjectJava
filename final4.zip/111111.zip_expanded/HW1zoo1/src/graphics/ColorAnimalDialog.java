package graphics;

import java.awt.FlowLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ColorAnimalDialog extends JDialog{
	
	MenuItemListener menuItemListener;
	static JComboBox c1;
	static JLabel l, l1;
	 ArrayList<String> s2;
	 String names[];
	 static JComboBox c2;
	 static JLabel m, m1;
	 JButton confirmButton;
		String selected,col;
	
	public ColorAnimalDialog(JFrame window,MenuItemListener menuItemListener,ArrayList<String> s) {
		 super(window, "Change Color", true);
	        this.menuItemListener = menuItemListener;
	        this.s2 = s;
	        this.names=new String[s.size()];
	        for(int i=0; i<s.size(); i++)
	        {
	        	this.names[i]=this.s2.get(i);
	        }
	        this.setLayout(new FlowLayout());
	        this.setSize(400, 300);
	        String s1[] = {};
	        c1 = new JComboBox(names);
	        l = new JLabel("select animal ");
	        l1 = new JLabel("selected");
	        JPanel p = new JPanel();
	        p.add(l);
	        p.add(c1);
	        p.add(l1);
	        this.add(p);
	        
	        
	        String s2[] = { "Natural", "Red", "Blue" };
	        c2 = new JComboBox(s2);
	        m = new JLabel("select color ");
	        m1 = new JLabel("selected");
	        JPanel p2 = new JPanel();

	        p2.add(m);
	 
	        // add combobox to panel
	        p2.add(c2);
	 
	        p2.add(m1);
	        this.add(p2);
	        
	        menuItemListener.setColorAnimalDialog(this, c1 , c2 );
	        
	        confirmButton = new JButton("Confirm");
	        confirmButton.setActionCommand("Confirm3");
			confirmButton.addActionListener(menuItemListener);
			this.add(confirmButton);
	        this.setVisible(true);
	}

}
