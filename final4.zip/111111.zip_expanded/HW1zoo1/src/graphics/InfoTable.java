package graphics;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import animals.Animal;

/**
 *A class that represents info table.
 * @version 1.0 2 May 2022
 * @author  Rita Vinitsky&Neta Mishael Tevet
 *
 */
public class InfoTable extends JFrame {
	 JFrame f;
	 JTable j;
	 
	 /**
		 * InfoTable's constructor.
		 * 
		 * @param animals - the animals array.
		 */
	 InfoTable(ArrayList<Animal> animals){
	     this.setSize(400, 300);
		 this.setTitle("Info");
		 String[][] data = new String[animals.size()+1][6];
		 int count=0;
		 for(int i=0 ; i<animals.size() ; i++)
		 {
			 data[i][0]= animals.get(i).getName();
			 data[i][1]=animals.get(i).getColor();
			 double w = animals.get(i).getWeight();
			 data[i][2] = Double.toString(w);
			 int h = animals.get(i).getHspeed();
			 data[i][3]=Integer.toString(h);
			 int v = animals.get(i).getVspeed();
			 data[i][4]=Integer.toString(v);
			 int e = animals.get(i).getEatCount();
			 data[i][5]=Integer.toString(e);
			 count+=e;
		 }
		 String finalcount = Integer.toString(count);
		 data[animals.size()][0]="Total";
		 data[animals.size()][1]=" ";
		 data[animals.size()][2]=" ";
		 data[animals.size()][3]=" ";
		 data[animals.size()][4]=" ";
		 data[animals.size()][5]=finalcount;
		 
		 String[] columnNames = { "Animal", "Color", "Weight","Hor.speed", "Ver.speed","Eat Counter" };
		 j = new JTable(data, columnNames);
	     j.setBounds(30, 40, 200, 300);
	     this.add(j);
	     JScrollPane sp = new JScrollPane(j);
	        this.add(sp);
	        // Frame Size
	        this.setSize(500, 200);
	        // Frame Visible = true
	     this.setVisible(true);

	 }

}



