package graphics;

public interface IChangeColor {
	
	public void changeColor(String color);

}
