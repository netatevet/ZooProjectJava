package graphics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import animals.Animal;
import animals.Bear;
import animals.Elephant;
import animals.Giraffe;
import animals.Lion;
import animals.Turtle;
import factories.AnimalFactory;
import factories.CarnivoreFactory;
import factories.Factory;
import factories.SampleAbstractFactory;
import mobility.Point;
import plants.Cabbage;
import plants.Lettuce;
import plants.Meat;


/**
 *A class that represents our action listener and manage all the commands in the program.
 *
 * @version 1.0 2 May 2022
 * @author  Rita Vinitsky&Neta Mishael Tevet
 *
 */
public class MenuItemListener implements ActionListener {
	JFrame frame;
	ZooPanel zooPanel;
	JPanel buttonPanel;
	AddAnimalDialog addAnimalDialog;
	JComboBox<String> animalSelect, c1, canimalselect;
	JTextField tbSize, x, y;
	JComboBox<String> color;
	JComboBox<String> changecolor;
	JComboBox<String> hspeed;
	JComboBox<String> vspeed;
	JLabel errorLabel,errorLabel2;
	//JLabel savanna;
	BufferedImage savanna;
	JLabel slabel;
	MoveAnimalDialog moveAnimalDialog;
	FoodAnimalDialog foodAnimalDialog;
	AddDietAnimalDialog addDietAnimalDialog;
	ColorAnimalDialog colorAnimalDialog;
	
	
	/**
	 * Frame setter. 
	 * 
	 * @param frame - the frame we want to set.
	 */
	public void setFrame(JFrame frame) {
		this.frame = frame; 
	}
	
	/**
	 * Panel setter. 
	 * 
	 * @param zooPanel - the panel we want to set.
	 */
	public void setPanel(ZooPanel zooPanel) {
		System.out.println("setPanel: " + zooPanel);
		this.zooPanel = zooPanel; 
	}
	
	/**
	 * Panel setter. 
	 * 
	 * @param buttonPanel - the panel we want to set.
	 */
	public void setbuttonPanel(JPanel buttonPanel) {
		this.buttonPanel = buttonPanel; 
	}
	
	/**
	 * AddAnimalDialog setter. 
	 * 
	 * @param addAnimalDialog - the AddAnimalDialog we want to set.
     * @param animalSelect - combobox.
     * @param tbSize - textfield.
     * @param color - combobox.
     * @param hspeed - combobox.
     * @param vspeed - combobox.
     * @param errorLabel - label.
	 */
	public void setAddAnimalDialog(AddAnimalDialog addAnimalDialog, JComboBox<String> animalSelect, JTextField tbSize, JComboBox<String> color, JComboBox<String> hspeed, JComboBox<String> vspeed, JLabel errorLabel ) {
		this.addAnimalDialog = addAnimalDialog;
		this.animalSelect = animalSelect;
		this.tbSize = tbSize;
		this.color = color;
		this.hspeed = hspeed;
		this.vspeed = vspeed;
		this.errorLabel = errorLabel;
	}
	
	/**
	 * MoveAnimalDialog setter. 
	 * 
	 * @param moveAnimalDialog - the MoveAnimalDialog we want to set.
     * @param c1 - combobox.
     * @param x - textfield.
     * @param y - textfield.
     * @param errorLabel - label.
     * @param errorLabe2 - label.
	 */
	public void setMoveAnimalDialog(MoveAnimalDialog moveAnimalDialog,JComboBox<String> c1,JTextField x,JTextField y, JLabel errorLabel,JLabel errorLabel2) {
		this.moveAnimalDialog = moveAnimalDialog; 
		this.c1 =c1 ;
		this.x = x;
		this.y = y;
		this.errorLabel = errorLabel;
		this.errorLabel2 = errorLabel2;

	}
	
	public void setColorAnimalDialog(ColorAnimalDialog colorAnimalDialog,JComboBox<String> canimalselect,JComboBox<String> color) {
		this.colorAnimalDialog = colorAnimalDialog; 
		this.changecolor = color;
		//this.c1 =c1 ;
		this.canimalselect = canimalselect;
		

	}
	
	/**
	 * FoodAnimalDialog setter. 
	 * 
	 * @param foodAnimalDialog - the FoodAnimalDialog we want to set.
	 */
	public void setFoodAnimalDialog(FoodAnimalDialog foodAnimalDialog) {
		this.foodAnimalDialog = foodAnimalDialog; 
	}
	
	public void setAddDietAnimalDialog(AddDietAnimalDialog addDietAnimalDialog) {
		this.addDietAnimalDialog = addDietAnimalDialog; 
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//System.out.println("actionPerformed: " + e);
		if(e.getActionCommand() == "Exit") {
			System.exit(0);
			return;
		}
		if(e.getActionCommand() == "Green") {
			zooPanel.setBackground(Color.green);
			slabel.setVisible(false);
			return;
		}
		if(e.getActionCommand() == "None") {
			zooPanel.setBackground(Color.white);
			slabel.setVisible(false);
			return;
		}
		
		if(e.getActionCommand() == "Image") {
			try {
				//zooPanel.setBackground(new Color(0,0,0,50));
			zooPanel.setBackground(null);
			savanna = ImageIO.read(new File(IDrawable.PICTURE_PATH+"\\savanna.jpg"));
			slabel = new JLabel();
			slabel.setBounds(0,0, 800, 600);
			Image im = savanna.getScaledInstance(slabel.getWidth(), slabel.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon imi = new ImageIcon(im);
			slabel.setIcon(imi);
			zooPanel.add(slabel);
			
			
			
			}
			catch(IOException e1) {
				e1.printStackTrace();
			}
			//savanna = new JLabel();
			//savanna.setIcon(new ImageIcon("C:\\Users\\Neta6\\Desktop\\hw2pic\\savanna.png"));
			//savanna.setBounds(0, 0, 800, 600);
			//this.zooPanel.add(savanna);
			//savanna.setVisible(true);
			return;
		}
		
		if(e.getActionCommand() == "Help") {
			JOptionPane.showMessageDialog(frame, "Home Work 2 \nGUI");
			return;
		}
		
		if(e.getActionCommand() == "Add") {
			if(zooPanel.queue.size()==5) {
				JOptionPane.showMessageDialog(frame, "You cannot add more than 15 animals");
			}
			
			//AddAnimalDialog newAddAnimalDialog = new AddAnimalDialog(frame, this);
			AddDietAnimalDialog newAddDietAnimalDialog = new AddDietAnimalDialog(frame,this);
			
			return;
		}
		
		if(e.getActionCommand() == "Carnivore") {
			AddAnimalDialog newAddAnimalDialog = new AddAnimalDialog(frame, this,"Carnivore");
			this.addDietAnimalDialog.dispose();

		
		}
		if(e.getActionCommand() == "Herbivore") {
			AddAnimalDialog newAddAnimalDialog = new AddAnimalDialog(frame, this,"Herbivore");
			this.addDietAnimalDialog.dispose();

			
		}
		if(e.getActionCommand() == "Omnivore") {
			AddAnimalDialog newAddAnimalDialog = new AddAnimalDialog(frame, this,"Omnivore");
			this.addDietAnimalDialog.dispose();

		}
		
		if(e.getActionCommand() == "Confirm") {
		  Object oselected = animalSelect.getSelectedItem();
		  addAnimalDialog.selected = String.valueOf(oselected);
		  
	      Object ocol = color.getSelectedItem();
	      addAnimalDialog.col = String.valueOf(ocol);
	      Object ohspeed = hspeed.getSelectedItem();
	      String shspeed = String.valueOf(ohspeed);
	      addAnimalDialog.hspeed = Integer.parseInt(shspeed);
	      Object ovspeed = vspeed.getSelectedItem();
	      String svspeed = String.valueOf(ovspeed);
	      addAnimalDialog.vspeed = Integer.parseInt(svspeed);
	      
	      String ssize=tbSize.getText();
	      try {
	    	  addAnimalDialog.size = Integer.parseInt(ssize);
	      } catch (final NumberFormatException error) {
	    	  errorLabel.setVisible(true);
	    	  return;
	      }
	      if(addAnimalDialog.size < 50 || addAnimalDialog.size > 300) {
	    	  errorLabel.setVisible(true);
	    	  return;
	      }
	      
		  if(addAnimalDialog.selected == "Lion") {
	        	//Lion lion = new Lion(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Lion");
//	        	lion.drawObject(g);
				
					//Lion lion =  new Factory(createAnimalFactory(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Lion");
			  AnimalFactory factory = SampleAbstractFactory.createAnimalFactory(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Lion");
			  Animal lion =  factory.createAnimal(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Lion");
				//Lion lion = CarnivoreFactory.createAnimal(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Lion");
	        	if(zooPanel.animals.size()==10)
	        	{
	        		//zooPanel.pool.execute(lion);
	        		zooPanel.queue.add(lion);
		        	zooPanel.manageZoo(); 

	        		
	        		
	        	}
	        	else {
	        	zooPanel.animals.add(lion);
	        	zooPanel.pool.execute(lion);
	        	zooPanel.manageZoo();
	        	}
	        	lion.setPanel(zooPanel);
	        	zooPanel.s.add("lion");
	        	
	        }
	        else if (addAnimalDialog.selected == "Bear") {
	        	//Bear bear = new Bear(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Bear");
	        	 AnimalFactory factory = SampleAbstractFactory.createAnimalFactory(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Bear");
				  Animal bear =  factory.createAnimal(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Bear");
	        	if(zooPanel.animals.size()==10)
	        	{
	        		//zooPanel.pool.execute(bear);
	        		zooPanel.queue.add(bear);
		        	zooPanel.manageZoo();

	        	}
	        	else {
	        	zooPanel.animals.add(bear);
	        	zooPanel.pool.execute(bear);
	        	zooPanel.manageZoo();

	        	}
	        	bear.setPanel(zooPanel);
	        	zooPanel.s.add("bear");
	        }
	        else if (addAnimalDialog.selected == "Elephant") {
	        	//Elephant elephant = new Elephant(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Elephant");
	        	 AnimalFactory factory = SampleAbstractFactory.createAnimalFactory(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Elephant");
				  Animal elephant =  factory.createAnimal(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Elephant");
	        	if(zooPanel.animals.size()==10)
	        	{
	        		//zooPanel.pool.execute(elephant);
	        		zooPanel.queue.add(elephant);
		        	zooPanel.manageZoo();

	        	}
	        	else {
	        	zooPanel.animals.add(elephant);
	        	zooPanel.pool.execute(elephant);
	        	zooPanel.manageZoo();

	        	}
	        	elephant.setPanel(zooPanel);
	        	zooPanel.s.add("elephant");

	        }
	        else if (addAnimalDialog.selected == "Giraffe") {
	        	//Giraffe giraffe = new Giraffe(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Giraffe");
	        	 AnimalFactory factory = SampleAbstractFactory.createAnimalFactory(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Giraffe");
				  Animal giraffe =  factory.createAnimal(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Giraffe");
	        	if(zooPanel.animals.size()==10)
	        	{
	        		//zooPanel.pool.execute(giraffe);
	        		zooPanel.queue.add(giraffe);
		        	zooPanel.manageZoo();

	        	}
	        	else {
	        	zooPanel.animals.add(giraffe);
	        	zooPanel.pool.execute(giraffe);
	        	zooPanel.manageZoo();

	        	}
	        	giraffe.setPanel(zooPanel);
	        	zooPanel.s.add("giraffe");

	        }
	        else if (addAnimalDialog.selected == "Turtle") {
	        	//Turtle turtle = new Turtle(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Turtle");
	        	 AnimalFactory factory = SampleAbstractFactory.createAnimalFactory(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Turtle");
				  Animal turtle =  factory.createAnimal(addAnimalDialog.size,addAnimalDialog.col,addAnimalDialog.hspeed,addAnimalDialog.vspeed,this.zooPanel,"Turtle");
	        	if(zooPanel.animals.size()==10)
	        	{
	        		//zooPanel.pool.execute(turtle);
	        		zooPanel.queue.add(turtle);
		        	zooPanel.manageZoo();

	        	}
	        	else {
	        	zooPanel.animals.add(turtle);
	        	zooPanel.pool.execute(turtle);
	        	zooPanel.manageZoo();

	        	}
	        	turtle.setPanel(zooPanel);
	        	zooPanel.s.add("turtle");

	        }
		  frame.add(zooPanel);
		  frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
      	  frame.pack();
      	  frame.setVisible(true);
		  
		  System.out.println("animals: " + zooPanel.animals);
		  addAnimalDialog.dispose();
//		  addAnimalDialog.setVisible(false);
		  zooPanel.manageZoo();
		  zooPanel.repaint();
		}
		if(e.getActionCommand() == "Confirm2") {
			  Object oselected = c1.getSelectedItem();
			  moveAnimalDialog.selected = String.valueOf(oselected);
			  
			  String sx=x.getText();
		      try {
		    	  moveAnimalDialog.x = Integer.parseInt(sx);
		      } catch (final NumberFormatException error) {
		    	  errorLabel.setVisible(true);
		    	  return;
		      }
		      if(moveAnimalDialog.x < 0 || moveAnimalDialog.x > 800) {
		    	  errorLabel.setVisible(true);
		    	  return;
		      }
		      
		      String sy=y.getText();
		      try {
		    	  moveAnimalDialog.y = Integer.parseInt(sy);
		      } catch (final NumberFormatException error) {
		    	  errorLabel2.setVisible(true);
		    	  return;
		      }
		      if(moveAnimalDialog.y < 0 || moveAnimalDialog.y > 600) {
		    	  errorLabel.setVisible(true);
		    	  return;
		      }
		      
		      Point p = new Point(moveAnimalDialog.x,moveAnimalDialog.y);
		     
		      for (int i=0 ; i<zooPanel.animals.size(); i++)
		      {
		    	  if(moveAnimalDialog.selected == (zooPanel.animals.get(i).getAnimalName())) {
		    		  zooPanel.animals.get(i).setLocation(p);
		    		  zooPanel.animals.get(i).setChanges(true);
		    		  zooPanel.manageZoo();
		    		  zooPanel.repaint();
		    	  }
		    	  
		      }
		      
		      
		      
		      
		      moveAnimalDialog.dispose();
		      
		      
			
		}
		
		if(e.getActionCommand() == "Confirm3") {
			Object oselected1 = canimalselect.getSelectedItem();
			  colorAnimalDialog.selected = String.valueOf(oselected1);
			 Object ocol1 = changecolor.getSelectedItem();
		      colorAnimalDialog.col = String.valueOf(ocol1);
		      
		      for (int i=0 ; i<zooPanel.animals.size(); i++)
		      {
		    	  if(colorAnimalDialog.selected == (zooPanel.animals.get(i).getAnimalName())) {
		    		  zooPanel.animals.get(i).setColor(colorAnimalDialog.col);
		    		  IChangeColor ichangecolor = new AnimalDecorator(zooPanel.animals.get(i));
		    		  ichangecolor.changeColor( colorAnimalDialog.col);
		    		  zooPanel.manageZoo();
		    		  zooPanel.repaint();
		    	  }
		    	  
		      }
		      colorAnimalDialog.dispose();
		      
		     // IChangeColor ichangecolor = new AnimalDecorator()
			
		}
		
		/*
		if(e.getActionCommand() == "Move") {
			MoveAnimalDialog a = new MoveAnimalDialog(frame,this,zooPanel.s);
			//zooPanel.manageZoo();
			return;
		}
		*/
		if(e.getActionCommand() == "Food") {
			FoodAnimalDialog a = new FoodAnimalDialog(frame,this);
			return;
		}
		if(e.getActionCommand() == "Cabbage") {
			Cabbage cab = Cabbage.getInstance(null);
			zooPanel.plant = cab;
			zooPanel.manageZoo();
  		    zooPanel.repaint();
			foodAnimalDialog.dispose();
			
			
			
			return;
		}
		
		if(e.getActionCommand() == "Lettuce") {
			Lettuce let = Lettuce.getInstance();
			zooPanel.plant = let;
			zooPanel.manageZoo();

			zooPanel.repaint();
			foodAnimalDialog.dispose();
			
			return;
		}
		
		if(e.getActionCommand() == "Meat") {
			Meat m = Meat.getInstance();
			zooPanel.plant = m;
			
			foodAnimalDialog.dispose();
			zooPanel.manageZoo();

			zooPanel.repaint();
			return;
		}
		
		if(e.getActionCommand() == "Color") {
			ColorAnimalDialog a = new ColorAnimalDialog(frame,this,zooPanel.s);
			return;
		}
		
		if(e.getActionCommand() == "Info") {
			InfoTable inf = new InfoTable(zooPanel.animals);
			return;
		}
		
		if(e.getActionCommand() == "Exit2") {
			System.exit(0);
			return;
		}
		
		if(e.getActionCommand() == "Clear") {
			this.zooPanel.animals.clear();
			this.zooPanel.s.clear();
			frame.add(zooPanel);
			frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
	      	frame.pack();
	      	frame.setVisible(true);
			zooPanel.manageZoo();

			return;
		}
		if(e.getActionCommand() == "Sleep") {
			for(int i=0;i<this.zooPanel.animals.size();i++) {
				this.zooPanel.animals.get(i).setSuspended();
				
			}
			return;
		}
		if(e.getActionCommand() == "Wake up") {
			for(int i=0;i<this.zooPanel.animals.size();i++) {
				this.zooPanel.animals.get(i).setResumed();
			}
			return;
		}
	}
		
	
}
	

