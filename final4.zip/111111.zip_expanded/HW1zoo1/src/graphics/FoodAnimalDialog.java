package graphics;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *A class that represents feeding animals in the zoo dialog.
 * @version 1.0 2 May 2022
 * @author  Rita Vinitsky&Neta Mishael Tevet
 *
 */
public class FoodAnimalDialog extends JDialog {

	MenuItemListener menuItemListener;

	static JLabel l;
	JButton LettuceButton;
	JButton CabbageButton;
	JButton MeatButton;

	 /**
   	 * FoodAnimalDialog's constructor.
   	 * 
   	 * @param window - the window that opens the dialog.
   	 * @param menuItemListener - the menuItemListener that manages the commands.
   	 */
	FoodAnimalDialog(JFrame window,MenuItemListener menuItemListener){
        super(window, "Food for animals", true);
    	this.menuItemListener = menuItemListener;

        //MenuItemListener menuItemListener = new MenuItemListener();
        this.setSize(400, 300);
        l = new JLabel("Please choose food ");
        this.add(l);
      
        JPanel buttonPanel = new JPanel();
        LettuceButton = new JButton("Lettuce");
        LettuceButton.setActionCommand("Lettuce");
        LettuceButton.addActionListener(menuItemListener);
        CabbageButton = new JButton("Cabbage");
        CabbageButton.setActionCommand("Cabbage");
        CabbageButton.addActionListener(menuItemListener);
        MeatButton = new JButton("Meat");
        MeatButton.setActionCommand("Meat");
        MeatButton.addActionListener(menuItemListener);
        buttonPanel.add(l);
        buttonPanel.add(LettuceButton);
		buttonPanel.add(CabbageButton);
		buttonPanel.add(MeatButton);
		
		this.add(buttonPanel);
		menuItemListener.setFoodAnimalDialog(this);
		this.setVisible(true);

	}

}
