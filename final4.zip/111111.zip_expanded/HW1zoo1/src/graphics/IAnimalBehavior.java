package graphics;


/**
 * An interface that describes the functionality of drawing images. 
 * 
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Animal
 *
 */
public interface IAnimalBehavior {
	
	/**
	 * Animal's name getter.
	 *
	 *@return Animals's name.
	 */
	public String getAnimalName();
	
	/**
	 * Size getter.
	 *
	 *@return object's size.
	 */
	public int getSize();
	
	/**
	 * Method that increase eat counter in 1.
	 *
	 *
	 */
	public void eatInc();
	
	/**
	 * Eat count getter.
	 *
	 *@return object's eat count field.
	 */
	public int getEatCount();
	
	/**
	 * Coor changed getter.
	 *
	 *@return animal's coor changed field.
	 */
	public boolean getChanges ();
	
	/**
	 * Coored changed field setter. 
	 * 
	 * @param state - the new state we want to set.
	 */
	public void setChanges (boolean state);
	public void setSuspended();
	public void setResumed();

}
