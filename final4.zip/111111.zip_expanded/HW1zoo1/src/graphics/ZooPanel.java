package graphics;

import java.awt.BorderLayout;
import java.lang.Math;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import animals.Animal;
import animals.Lion;
import diet.Carnivore;
import diet.Herbivore;
import diet.Omnivore;
import food.EFoodType;
import plants.Cabbage;
import plants.Lettuce;
import plants.Meat;
import plants.Plant;
import utilities.Controller;

/**
 *A class that represents zoo panel.
 * @version 1.0 2 May 2022
 * @author  Rita Vinitsky&Neta Mishael Tevet
 *
 */
public class ZooPanel extends JPanel implements Runnable  {
	
	JPanel buttonPanel;
	ArrayList<Animal> animals;
	ArrayList<String> s;
	MenuItemListener menuItemListener;
	public Plant plant;
	//private Thread controller;
	ExecutorService pool;
	Queue<Animal> queue;
	private static ZooPanel instance = null;
	Controller controller;
	
	/**
	 * ZooPanel's constructor.
	 * 
	 * @param menuItemListener - the menuItemListener that manages the commands.
	 */
	private ZooPanel(MenuItemListener menuItemListener){
		
		plant = null;
		buttonPanel = new JPanel();
		//menuItemListener.setPanel(this);
		//this.menuItemListener = menuItemListener;
		JButton addButton = new JButton("Add");
		addButton.setActionCommand("Add");
		addButton.addActionListener(menuItemListener);
		//JButton moveBotton = new JButton("Move");
		//moveBotton.setActionCommand("Move");
		//moveBotton.addActionListener(menuItemListener);
		JButton sleepBotton = new JButton("Sleep");
		sleepBotton.setActionCommand("Sleep");
		sleepBotton.addActionListener(menuItemListener);
		JButton wakeupBotton = new JButton("Wake up");
		wakeupBotton.setActionCommand("Wake up");
		wakeupBotton.addActionListener(menuItemListener);
		JButton clearBotton = new JButton("Clear");
		clearBotton.setActionCommand("Clear");
		clearBotton.addActionListener(menuItemListener);
		JButton foodBotton = new JButton("Food");
		foodBotton.setActionCommand("Food");
		foodBotton.addActionListener(menuItemListener);

		JButton colorButton = new JButton("Change Color");
		colorButton.setActionCommand("Color");
		colorButton.addActionListener(menuItemListener);
		JButton infoBotton = new JButton("Info");
		infoBotton.setActionCommand("Info");
		infoBotton.addActionListener(menuItemListener);
		JButton exitBotton = new JButton("Exit");
		exitBotton.setActionCommand("Exit2");
		exitBotton.addActionListener(menuItemListener);
		
		buttonPanel.add(addButton);
		
		 
		//buttonPanel.add(moveBotton);
		buttonPanel.add(sleepBotton);
		buttonPanel.add(wakeupBotton);
		buttonPanel.add(clearBotton);
		buttonPanel.add(foodBotton);
		buttonPanel.add(colorButton);
		buttonPanel.add(infoBotton);
		buttonPanel.add(exitBotton);
		BorderLayout myBorderLayout = new BorderLayout();
		this.setLayout(myBorderLayout);
		this.add(buttonPanel,BorderLayout.SOUTH);
		this.animals = new ArrayList<>();
		this.s = new ArrayList<>();
		
	    //this.controller = new Thread(this);
		//this.controller.start();
		this.controller = new Controller(this);
		

		
		this.pool = Executors.newFixedThreadPool(10);
		//for(int i=0; i<this.animals.size();i++) {
		//	pool.execute(animals.get(i));
		//}

		//pool.shutdown();
		this.queue = new LinkedList<> ();
		
		
	
	}
	
	public static ZooPanel getInstance(MenuItemListener menuItemListener) { 
		if(instance == null) { 
			instance = new ZooPanel(menuItemListener); 
		} 
		return instance; 
	} 

	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if(this.animals.size() > 0) {
			for(int i = 0 ; i < this.animals.size() ; i++)
				this.animals.get(i).drawObject(g);
		}
		if(plant != null) {
			this.plant.drawObject(g);
		}
	}
	
	/**
	 * The method that manages the zoo and follows changes.
	 * 
	 */
public void manageZoo() {
	
	for(int i = 0 ; i < this.animals.size() ; i++) {
		this.animals.get(i).addObserver(controller);
	}

	for(int i = 0 ; i < this.animals.size() ; i++) {
		if(plant != null) {
	
		if((Math.abs(this.animals.get(i).getLocation().getX() - plant.getLocation().getX())<=10) &&( Math.abs(this.animals.get(i).getLocation().getY() - plant.getLocation().getY())<=10 )) {
			if(this.animals.get(i) instanceof Herbivore &&( plant instanceof Cabbage || plant instanceof Lettuce )) {
				this.animals.get(i).eat(plant);
				this.animals.get(i).eatInc();
				plant = null;
				this.repaint();
			}
			else if (this.animals.get(i) instanceof Carnivore && plant instanceof Meat) {
				this.animals.get(i).eat(plant);
				this.animals.get(i).eatInc();
				plant = null;
				this.repaint();
			}
			else if (this.animals.get(i) instanceof Omnivore ) {
				this.animals.get(i).eat(plant);
				this.animals.get(i).eatInc();
				plant = null;
				this.repaint();
			}
			
			
			
		}
		
	}
		if (this.animals.get(i).getChanges() == true) {
			this.repaint();
		}
	}
		
	for(int i = 0 ; i < this.animals.size() ; i++)
	{
		for(int j = 0 ; j < this.animals.size() ; j++)
		{
			if(this.animals.get(i) instanceof Carnivore || this.animals.get(i) instanceof Omnivore)
			{
				if(((this.animals.get(j) instanceof Herbivore) || (this.animals.get(j) instanceof Omnivore))&&(this.animals.get(i).getWeight()>= 2*this.animals.get(j).getWeight())&& (this.animals.get(i).calcDistance(this.animals.get(j).getLocation())<=this.animals.get(j).getSize())){
					   this.animals.get(i).eat(this.animals.get(j));
					   this.animals.get(i).eatInc();
					   animals.remove(j);
					   s.remove(j);
					   if(!queue.isEmpty()) {
						   Animal newanimal =queue.poll();
						  
					   animals.add(newanimal);
					    
					   
					   pool.execute(newanimal);
					   
					   }
					   this.repaint();
					   
						}
					
					
				
			 

			
		     }
			

	     }
	
   //(isChange())

        //repaint();



 // all other checks need to be done in the zoo (eating, etc....)

}
	/*
	for(int i = 0 ; i < this.animals.size() ; i++) {
	  if(this.animals.get(i).getS()==false && this.animals.get(i).getThread().getState()== Thread.State.WAITING ) {
		  this.animals.get(i).notify();
	  }
	}
	*/
	}
/**
 * The method that manages the zoo and follows changes.
 * 
 */
public void run() {
  manageZoo();
}
}



	


	

	


