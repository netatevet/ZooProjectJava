package mobility;

import java.applet.Applet;
import java.util.Observable;

//import diet.Lion;
import utilities.MessageUtility;


/**
 *  An abstract class that defines motion in space.

 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Animal
 */
public abstract class Mobile extends Observable implements Ilocatable {
	  private Point location;
	  private double totalDistance;
	  
	  /**
		 * Mobile's constructor.
		 * 
		 * @param p - Point that represents object's starting location.
		 */
	  public Mobile(Point p){
		  location = new Point(p);    
		  totalDistance=0;
		 
	  }
	  
	  /**
	   * Adding distance to the total distance.
	   * 
	   * @param d - the distance we want to add.
	   */
	  public void addTotalDistance(double d){
		  totalDistance=totalDistance+d;
	  }
	  
	  
	  /**
	   * Calculation of distance between 2 points by Pythagoras' theorem.
	   * 
	   * @param p - The point that describes the location that we want to calculate the distance between it and the object's location.
	   * @return distance between 2 points by Pythagoras' theorem.
	   */
	  public double calcDistance(Point p){
		  return (Math.sqrt(Math.pow(location.getX()-p.getX(),2)-Math.pow(location.getY()-p.getY(),2)));
	  }
	  
	  
	  /**
	   * Calculating distance between 2 points, adding to total distance, updates the current object's location.
	   * 
	   * @param p - the location we want the object will move to.
	   * @return the distance between the two locations.
	   */
	  public double move(Point p) {
		 if( Point.checkBoundaries(p) == false)
			 return 0;
		 double distance=this.calcDistance(p);
		 this.addTotalDistance(distance);
		 this.setLocation(p);
		 return distance;
	  }
	  
	  @Override
	  public Point getLocation() {
		  MessageUtility.logGetter(this.getClass().getSimpleName(), "getLocation", this.location);
		  return location;
	  }
	  
	  @Override
	  public boolean setLocation(Point p) {
		 boolean isSuccess = false;
		 if(Point.checkBoundaries(p)) {
			 this.location=new Point(p);
			 isSuccess = true;
		 }
		 MessageUtility.logSetter(this.getClass().getSimpleName(), "setLocation", p, isSuccess);
		 return isSuccess;
	  }
	  
	public void setLocation (int hor, int x_dir, int ver, int y_dir) {
		this.location.setX(this.location.getX()+hor*x_dir);
		this.location.setY(this.location.getY()+ver*y_dir);
		
	}


}
