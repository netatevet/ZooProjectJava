package mobility;



/**
 * A class that defines a position on a dimensional axis.
 *
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Mobile
 */
public class Point {
	  public static final int maxX=800;
	  public static final int maxY=600;
	  public static final int min=0;  
	  private int x;
	  private int y;
	  
	  /**
	   * Getter for x.
	   * 
	   * @return x class member.
	   */
	  public int getX(){
	    return this.x;
	  }
	  
	  /**
	   * Getter for y.
	   * 
	   * @return y data member.
	   */
	  public int getY(){
	    return this.y;
	  }
	  
	  /**
	   * Checks if point is the the permitted limits.
	   * 
	   * @param pointToCheck - the point we want to check if it in the permitted limits.
	   * @return true - if the point is in the permitted limits.
	   *         false - if doesn't.
	   */
	  public static boolean checkBoundaries(Point pointToCheck){
	    if (pointToCheck.getX() >=min && pointToCheck.getX()<=maxX && pointToCheck.getY()>=min && pointToCheck.getY()<=maxY)
	    	return true;
	    return false;
	  }
	  
	  /**
	   * Point's constructor.
	   * 
	   * @param x - Position on axis x.
	   * @param y - Position on axis y.
	   */
	  public Point(int x,int y){
		      this.x=x;
		      this.y=y;
		}
	  
	  /**
	   * Copy constructor.
	   * 
	   * @param p - the point we want to copy.
	   */
		public Point(Point p){
		 this.x=p.getX();
		 this.y=p.getY();
		}

		
		@Override
		public String toString() {
			return "(" + this.getX() + ", " + this.getY() + ") ";
		}
		
		public void setX(int x) {
			if (x>=min && x<=maxX) {
			this.x = x;
			}
		}

		public void setY(int y) {
			if (y>=min && y<=maxY) {
			this.y = y;
			}
		}
}
