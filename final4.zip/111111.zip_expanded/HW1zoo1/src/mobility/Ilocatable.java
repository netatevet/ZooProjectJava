package mobility;

/**
Interface that describes the functionality of a location.
 * 
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Mobile
 *
 */
public interface Ilocatable {
	
	/**Getter for object's current location.
	 * 
	 * @return Point - object's current location.
	 */
	 public Point getLocation();
	 
	 /**
	  * Setter for object's location.
	  * 
	  * @param p - the new location we want to set.
	  * @return true - if the location succeed.
	  *         false - if does'nt.
	  */
	 public boolean setLocation(Point p);


}
