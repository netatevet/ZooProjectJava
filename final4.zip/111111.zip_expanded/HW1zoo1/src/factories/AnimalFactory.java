package factories;

import animals.Animal;
import graphics.ZooPanel;

public interface AnimalFactory {
    public Animal createAnimal(int size,String col,int h, int v,ZooPanel zooPanel,String type);
}
