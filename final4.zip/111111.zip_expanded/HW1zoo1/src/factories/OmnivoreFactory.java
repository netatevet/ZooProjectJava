package factories;

import animals.Animal;
import animals.Bear;
import animals.Lion;
import graphics.ZooPanel;

public class OmnivoreFactory implements AnimalFactory {
	public Animal createAnimal(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		return new Bear(size,col,h,v,zooPanel,type);
	}

}
