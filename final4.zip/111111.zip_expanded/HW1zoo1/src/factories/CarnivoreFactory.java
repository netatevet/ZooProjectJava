package factories;

import animals.Animal;
import animals.Lion;
import graphics.ZooPanel;

public class CarnivoreFactory implements AnimalFactory {

	public Animal createAnimal(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		return new Lion(size,col,h,v,zooPanel,type);
	}
}
