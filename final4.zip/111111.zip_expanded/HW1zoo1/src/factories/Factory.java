package factories;

import animals.Animal;
import graphics.ZooPanel;

public class Factory {
	public Factory(AnimalFactory factory,int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		Animal animal = factory.createAnimal(size,col,h, v,zooPanel,type);
		
	}
	


}
