package factories;

import graphics.ZooPanel;

public class SampleAbstractFactory {
	
	
	public static AnimalFactory createAnimalFactory(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		if("Lion".equals(type)) return new CarnivoreFactory();
		if("Bear".equals(type)) return new OmnivoreFactory();
		else {
			return new HerbivoreFactory();
		}

	}

}
