package factories;

import animals.Animal;
import animals.Elephant;
import animals.Giraffe;
import animals.Lion;
import animals.Turtle;
import graphics.ZooPanel;

public class HerbivoreFactory implements AnimalFactory {
	public Animal createAnimal(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
		if(type == "Turtle")
		{
			return new Turtle(size,col,h,v,zooPanel,type);
		}
		else if(type == "Giraffe") {
			return new Giraffe(size,col,h,v,zooPanel,type);

		}
		else
		{
			return new Elephant(size,col,h,v,zooPanel,type);

		}
	}
}
