package zoo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import animals.Animal;
import animals.Bear;
import animals.Elephant;
import animals.Giraffe;
import animals.Lion;
import animals.Turtle;
import food.IEdible;
import mobility.Point;

/**
 *  A class describing static methods and the main function.

 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 *
 */
public class ZooActions {
	
	/**
	 * Static method describing eating of animal another animal.
	 * 
	 * @param animal - the animal that will eat.
	 * @param food - the object that will be eaten.
	 * @return true - if the animal can eat the object.
	 *         false - if does'nt.
	 */
	public static boolean eat(Object animal, IEdible food) {
		if(animal instanceof Lion)
		{
			return ((Lion)animal).eat(food);
		}
		if(animal instanceof Bear)
		{
			return ((Bear)animal).eat(food);
		}
		if(animal instanceof Elephant)
		{
			return ((Elephant)animal).eat(food);
		}
		if(animal instanceof Giraffe)
		{
			return ((Giraffe)animal).eat(food);
		}
		if(animal instanceof Turtle)
		{
			return ((Turtle)animal).eat(food);
		}
		return false;
	}
	
	/**
	 * Static method describing animals movement in the zoo.
	 * 
	 * @param animal - the animal that will move to another location.
	 * @param point - the new location.
	 * @return true - if the new location in the zoo borders.
	 *         false - if the new location is not in the new borders and the animal will not move.
	 */
	public static boolean move(Object animal, Point point) {
		if (Point.checkBoundaries(point) == false)
		{
			return false;
		}
		
		if(animal instanceof Lion)
		{
			 ((Lion)animal).move(point);
			 return true;
		}
		if(animal instanceof Bear)
		{
			((Bear)animal).move(point);
			 return true;
		}
		if(animal instanceof Elephant)
		{
			((Elephant)animal).move(point);
			 return true;
		}
		if(animal instanceof Giraffe)
		{
			((Giraffe)animal).move(point);
			 return true;
		}
		if(animal instanceof Turtle)
		{
			((Turtle)animal).move(point);
			 return true;
		}
		return false;
	}
		
	
	/**
	 * the main function.
	 * 
	 * @param args
	 */
	/*
		public static void main(String [] args) {
			List<Animal> animals = new ArrayList<>();
			Scanner scanner = new Scanner(System.in);
			
			int numOfAnimals = 0;
			while(numOfAnimals<3) {
			System.out.println("Enter number of animals(min 3):");
			numOfAnimals = scanner.nextInt();
			scanner.nextLine();
			}
			
			
			for(int i=0;i<numOfAnimals;) {
				System.out.println("Enter animal type");
				String animallType=scanner.nextLine();
				if(animallType.startsWith("Lion"))
				{
					System.out.println("Enter lion's name");
					String name=scanner.nextLine();
					
					Lion newLion = new Lion(name);
					animals.add(newLion);
					System.out.println(newLion);
					i=i+1;
					continue;
				}
				if(animallType.startsWith("Bear")) {
					System.out.println("Enter bear's name");
					String name=scanner.nextLine();
					
					Bear newBear = new Bear(name);
					animals.add(newBear);
					System.out.println(newBear);
					i=i+1;
					continue;
				}
				if(animallType.startsWith("Turtle")) {
					System.out.println("Enter turtle's name");
					String name=scanner.nextLine();
					
					Turtle newTurtle = new Turtle(name);
					animals.add(newTurtle);
					System.out.println(newTurtle);
					i=i+1;
					continue;
				}
				if(animallType.startsWith("Elephant")) {
					System.out.println("Enter elephant's name");
					String name=scanner.nextLine();
					
					Elephant newElephant = new Elephant(name);
					animals.add(newElephant);
					System.out.println(newElephant);
					i=i+1;
					continue;
				}
				if(animallType.startsWith("Giraffe")) {
					System.out.println("Enter giraffe's name");
					String name=scanner.nextLine();
					
					Giraffe newGiraffe = new Giraffe(name);
					animals.add(newGiraffe);
					System.out.println(newGiraffe);
					i=i+1;
					continue;
				}
				else {
					System.out.println("Animal like this does'nt exict try again.");
				}   continue;
			}
			for(int i=0;i<animals.size();i=i+1)
			{
				System.out.println("name: " + animals.get(i).getName() + ", Location: " + animals.get(i).getLocation());
			}
			
			int x;
			int y;
			System.out.println("Enter x that you want the animals will move to");
			x = scanner.nextInt();
			System.out.println("Enter y that you want the animals will move to");
			y = scanner.nextInt();
			
			 Point p = new Point(x,y);
			
			for(int i=0;i<animals.size();i=i+1)
			{
				ZooActions.move(animals.get(i), new Point(p));
			}
			for(int i=0;i<animals.size();i=i+1)
			{
				System.out.println("name: " + animals.get(i).getName() + ", Location: " + animals.get(i).getLocation());
			}
			
			Random rand = new Random();
			for(int i=0;i<animals.size()/2;i=i+1)
			{
				int first = rand.nextInt(animals.size());
				int second = rand.nextInt(animals.size());
				while(second == first) {
					second = rand.nextInt(animals.size());
				}
				IEdible secondFood = (IEdible)(animals.get(second));
				Animal firstFood = animals.get(first);
				System.out.println(firstFood.getName() + " is trying to eat " + animals.get(second).getName());
				boolean ate = ZooActions.eat(firstFood, secondFood);
			}
		
			
	}
	*/

}
