package animals;

import diet.Herbivore;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;

/**
 *A class that represents a turtle.
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 *
 */
public class Turtle extends Herbivore {
	private int age;
	
	/**
	 * Turtle's constructor.
	 * 
	 * @param name - turtle's name.
	 */
	public Turtle(String name) {
		super(name,new Point(80,0));
		MessageUtility.logConstractor("Turtle", name);
		this.setWeight(1);
		this.setAge(1);
	}
	
	/**
	 * Turtle's constructor.
	 * 
	 * @param name - turtle's name.
	 * @param location - turtle's starting location.
	 */
	public Turtle(String name,Point location) {
		super(name,location);
		MessageUtility.logConstractor("Turtle", name);
		this.setWeight(1);
		this.setAge(1);
	}
	public Turtle(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
	    super(size,col,h,v,zooPanel,type);
	    this.setLocation(new Point(80,0));
	    this.setWeight(size*0.5);	   
	    this.setName("turtle");	
	    this.setImg();
	}
	public void setImg()
	{
		this.loadImages("trt");
	}
	/**
	 * Turtle's constructor.
	 * 
	 * @param name - turtle's name.
	 * @param age - turtle's age.
	 */
	public Turtle(String name, int age) {
		super(name,new Point(80,0));
		MessageUtility.logConstractor("Turtle", name);
		this.setWeight(1);
		this.setAge(age);
	}
	
	public void chew() {
		MessageUtility.logSound(this.getName(), "Retracts its head in then eats quietly");
	}
	@Override
	public EFoodType getFoodType() {
		
		return EFoodType.MEAT;
	}
	@Override
	public void makeSound() {
		this.chew();
		
	}
	@Override
	public boolean eat(IEdible food) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	/**
	 * Turtle's age setter.
	 * 
	 * @param newage -the age we want to set.
	 * @return true - if the set succeed.
	 *         false - if does'nt.
	 */
	public boolean setAge(int newage) {
		if(newage>=0 && newage<=500)
		{
			this.age=newage;
			MessageUtility.logSetter(this.getName(), "setAge", newage, true);
			return true;
		}
		MessageUtility.logSetter(this.getName(), "setAge", newage, false);
		return false;
	}
}
