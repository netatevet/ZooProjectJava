package animals;

import diet.Herbivore;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;

/**
 *A class that represents an elephant.
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 *
 */
public class Elephant extends Herbivore {
	private double  trunkLength;
	
	/**
	 * Elephant's constructor.
	 * 
	 * @param name - elephant's name.
	 */
	public Elephant(String name) {
		super(name,new Point(50,90));
		MessageUtility.logConstractor("Elephant", name);
		this.setWeight(500);
		this.trunkLength=1;
	}
	
	/**
	 * Elephant's constructor.
	 * 
	 * @param name - elephant's name.
	 * @param location - elephant's starting locatin.
	 */
	public Elephant(String name,Point location) {
		super(name,location);
		MessageUtility.logConstractor("Elephant", name);
		this.setWeight(500);
		this.trunkLength=1;
	}
	public Elephant(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
	    super(size,col,h,v,zooPanel,type);
	    this.setLocation(new Point(50,90));
	    this.setWeight(size*10);	   
	    this.setName("elephant");	
	    this.setImg();
	}
	public void setImg()
	{
		this.loadImages("elf");
	}
		

	
	/**
	 * Elephant's constructor.
	 * 
	 * @param name - elephant's name.
	 * @param trunk - elephant's trunk length.
	 */
	public Elephant(String name, double trunk) {
		super(name,new Point(50,90));
		MessageUtility.logConstractor("Elephant", name);
		this.setWeight(500);
		this.settrunkLength(trunk);
	}
	
	
	public void chew() {
		MessageUtility.logSound(this.getName(), "Trumpets with joy while flapping its ears, then chews");
	}
	
	@Override
	public EFoodType getFoodType() {
		
		return EFoodType.MEAT;
	}
	
	@Override
	public void makeSound() {
		this.chew();
		
	}
	
	@Override
	public boolean eat(IEdible food) {
		// TODO Auto-generated method stub
		return false;
	}
	
	/**
	 * Elephnt's trunk length setter.
	 * 
	 * @param newtrunk - the new trunk length.
	 * @return - true - if the set succeed.
	 *         false - if does'nt.
	 */
	public boolean settrunkLength(double newtrunk) {
		if(newtrunk>=0.5 && newtrunk<=3)
		{
			this.trunkLength=newtrunk;
			MessageUtility.logSetter(this.getName(), "settrunkLength", newtrunk, true);
			return true;
		}
		MessageUtility.logSetter(this.getName(), "settrunkLength", newtrunk, false);
		return false;
	}
	
		
		
}
