package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import diet.Carnivore;
import diet.Herbivore;
import diet.IDiet;
import diet.Omnivore;
import food.IEdible;
import graphics.IAnimalBehavior;
import graphics.IChangeColor;
import graphics.IDrawable;
import graphics.ZooPanel;
//import mobility.Animal;
import mobility.Mobile;
import mobility.Point;
import plants.Cabbage;
import plants.Lettuce;
import plants.Meat;
import utilities.MessageUtility;


/**
 *An abstract class that defines the characteristics common to all animals.
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     Lion,Bear,Elephant,Giraffe,Turtle
 */
public abstract class Animal extends Mobile implements IEdible,IAnimalBehavior,IDrawable,Runnable,IChangeColor {
	
	private String name;
	private double weight;
	private IDiet diet;
	
	private final int EAT_DISTANCE = 10;
	private int size;
	private String col;
	private int horSpeed;
	private int verSpeed;
	private boolean coordChanged;
	//private Thread thread;
	private int x_dir;
	private int y_dir;
	private int eatCount;
	private ZooPanel pan;
	public BufferedImage img1, img2;
	//protected Thread thread;
	protected boolean threadSuspended;
	private boolean exit = false;
	
	
	
	/**
	 * Animal's constructor.
	 * 
	 * @param name - animal's name.
	 * @param location - animal's starting location.
	 */
	public Animal(String name,Point location) {
		super(location);
		MessageUtility.logConstractor("Animal", name);
		this.setName(name);
	}
	
	/**
	 * Animal's constructor.
	 * 
	 * @param size - animal's name.
	 * @param col - animal's color.
	 * @param h - animal's horizontal speed.
	 * @param v - animal's vertical speed.

	 */
	public Animal(int size,String col,int h, int v, ZooPanel zooPanel,String type) {
		super(new Point(0,0));
		this.size = size;
		this.col = col;
		this.horSpeed=h;
		this.verSpeed=v;
		this.setPanel(zooPanel);
		this.eatCount=0;
		this.coordChanged = false;
		this.x_dir=1;
		this.y_dir=1;
		this.threadSuspended = false;
		//this.thread = new Thread(this);
		//this.thread.start();
		
		
		
	}
	
	public synchronized void stop()
	{
		exit = true;
	}
	
	/**
	 * Weight setter. 
	 * 
	 * @param weight - the weight we want to set.
	 * @return true - if the set succeed.
	 *         false - if does'nt.
	 */
	public boolean setWeight(double weight) {
		boolean isSuccess =(weight >= 0);
		if (isSuccess) {
			this.weight = weight;
		} else {
			this.weight = 0;
		}
		MessageUtility.logSetter(this.name, "setWeight", weight, isSuccess);

		return isSuccess;
	}
	
	/**
	 * Weight getter.
	 * 
	 * @return animal's weight.
	 */
	public double getWeight() {
		MessageUtility.logGetter(this.getClass().getSimpleName(), "getWeight", this.weight);
		return weight;
	}
	
	/**
	 * Name getter.
	 * 
	 * @return animal's name.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Name setter.
	 * 
	 * @param newname - the new name we want to set.
	 * @return true - is the set succeed.
	 *         false - if doesn't.
	 */
	public boolean setName(String newname) {
		this.name=newname;
		MessageUtility.logSetter(this.name, "setName", newname, true);
		return true;
	}
	
	public void setPanel(ZooPanel zooPanel) {
		this.pan = zooPanel;
	}
	
	/**
	 * Abstract function that represent the sound an animal make after eating.
	 */
	public abstract void makeSound();
	
	/**
	 * Abstract function for eating.
	 * 
	 * @param food
	 * @return true- if the eating succeed.
	 *         false - if doesn't.
	 */
	public abstract boolean eat(IEdible food);
	
	
	/**
	 * Function that represent what happened after eating.
	 * @param gained - the weight that was gained while eating.
	 * @return true - if the eating succeed.
	 *         false - if doesn't.
	 */
	public boolean afterEat(double gained) {
		if(gained>0) {
			this.setWeight(gained+this.getWeight());
			this.makeSound(); 
			return true;
		 }
		return false;
	}

	@Override
	public String toString() {
		return "[" + this.getClass().getSimpleName() + "] :" + this.name;
	}
	
	@Override
	public String getAnimalName() {
		return this.name;
	}
	
	@Override
	public int getSize() {
		return this.size;
	}
	
	
	public boolean setEatCount(int c) {
		this.eatCount=c;
		return true;
	}
	
	@Override
	public void eatInc() {
		this.setEatCount(this.eatCount+1);
	}
	
	
	public int getEatCount() {
		return this.eatCount;
	}
	
	
	public boolean getChanges () {
		return this.coordChanged;
	}
	
	
	public void setChanges (boolean state) {
		this.coordChanged = state;
	}
	
	
	public String getColor() {
		return this.col;
	}
	
	public boolean getS() {
		return threadSuspended;
	}
	
	//public Thread getThread() {
	//	return Thread;
	//}
	public void loadImages(String nm) {
		try {
			if(this.col=="Blue") {
			this.img1 = ImageIO.read(new File(PICTURE_PATH+"\\"+nm+"_b_1.png")); 
			this.img2 = ImageIO.read(new File(PICTURE_PATH+"\\"+nm+"_b_2.png")); 
			
			}
			else if(this.col=="Red") {
				this.img1 = ImageIO.read(new File(PICTURE_PATH+"\\"+nm+"_r_1.png")); 
				this.img2 = ImageIO.read(new File(PICTURE_PATH+"\\"+nm+"_r_2.png")); 
				
				}
			else if(this.col=="Natural") {
				this.img1 = ImageIO.read(new File(PICTURE_PATH+"\\"+nm+"_n_1.png")); 
				this.img2 = ImageIO.read(new File(PICTURE_PATH+"\\"+nm+"_n_2.png")); 
				
			}
		}
		catch (IOException e) { System.out.println("Cannot load image"); }
	}
	
	
	public void drawObject (Graphics g) {
		if(this.x_dir==1) // giraffe goes to the right side
			g.drawImage(this.img1, this.getLocation().getX()-size/2, this.getLocation().getY()-size/10, size/2, size, pan);
		else // giraffe goes to the left side
			g.drawImage(this.img2, this.getLocation().getX(), this.getLocation().getY()-size/10, size/2, size, pan);
	}
	
	/*
	public void setImg(String nm)
	{
		this.loadImages(nm);
	}
	*/
	public void setImg()
	{
		this.loadImages("anm");
	}
	
	public void paint(Graphics g) {
		drawObject(g);
	}
	
	public int getHspeed() {
		return this.horSpeed;
	}
	
	public int getVspeed() {
		return this.verSpeed;
	}
	
	public int getEatDistance() {
		return EAT_DISTANCE ;
	}
	
	public synchronized void setSuspended() {
		this.threadSuspended = true;
		
	}
	
	public  synchronized void setResumed() {
		this.threadSuspended = false;
		notify();
	
	}
	
	public void setVspeed(int v) {
		this.verSpeed=v;
	}
	
	public void setColor(String color) {
		this.col = color;
	}
	/**
	 * Function that manage the mobility of the animals .
	
	 */
	public void run() {
		while(!exit)
		{
	
		while(threadSuspended == false) {
			this.setLocation(horSpeed, x_dir, verSpeed, y_dir);
			pan.repaint();
			pan.manageZoo();
			if(this.getLocation().getX() == 800)
			{
				this.x_dir = -1;
			}
			if(this.getLocation().getX() == 0)
			{
				this.x_dir = 1;
			}
			if(this.getLocation().getY() == 600)
			{
				this.y_dir = -1;
			}
			if(this.getLocation().getY() == 0)
			{
				this.y_dir = 1;
			}
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(this.pan.plant!=null) {
				if(this instanceof Herbivore &&( this.pan.plant instanceof Cabbage || this.pan.plant instanceof Lettuce )) {
					if(this.getLocation().getX()<400 && x_dir == 1) {
						this.verSpeed=0;
						this.getLocation().setY(300);
						
					}
					else if(this.getLocation().getX()>400 && x_dir == 1) {
                    	this.x_dir=-1;
                    	this.verSpeed=0;
						this.getLocation().setY(300);
					}
					else if(this.getLocation().getX()<400 && x_dir == -1) {
                    	this.x_dir=1;
                    	this.verSpeed=0;
						this.getLocation().setY(300);
					}
					else if(this.getLocation().getX()>400 && x_dir == -1) {
                    	this.verSpeed=0;
						this.getLocation().setY(300);
					}

				}
				else if (this instanceof Carnivore && this.pan.plant instanceof Meat) {if(this.getLocation().getX()<400 && x_dir == 1) {
					this.verSpeed=0;
					this.getLocation().setY(300);
					
				}
				else if(this.getLocation().getX()>400 && x_dir == 1) {
                	this.x_dir=-1;
                	this.verSpeed=0;
					this.getLocation().setY(300);
				}
				else if(this.getLocation().getX()<400 && x_dir == -1) {
                	this.x_dir=1;
                	this.verSpeed=0;
					this.getLocation().setY(300);
				}
				else if(this.getLocation().getX()>400 && x_dir == -1) {
                	this.verSpeed=0;
					this.getLocation().setY(300);
				}
}
				else if (this instanceof Omnivore ) {
					if(this.getLocation().getX()<400 && x_dir == 1) {
						this.verSpeed=0;
						this.getLocation().setY(300);
						
					}
					else if(this.getLocation().getX()>400 && x_dir == 1) {
                    	this.x_dir=-1;
                    	this.verSpeed=0;
						this.getLocation().setY(300);
					}
					else if(this.getLocation().getX()<400 && x_dir == -1) {
                    	this.x_dir=1;
                    	this.verSpeed=0;
						this.getLocation().setY(300);
					}
					else if(this.getLocation().getX()>400 && x_dir == -1) {
                    	this.verSpeed=0;
						this.getLocation().setY(300);
					}

				}
				
			}
		}
		
		while(threadSuspended)
		{
			synchronized(this) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
		}
		 
		/*
		if(threadSuspended==true)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(threadSuspended==false && this.thread.getState()== Thread.State.WAITING ) {
			  notify();
		  }
		*/
		setChanged();
		
		
	}
	public void changeColor(String color) {
		setImg();
		
		
		
	}



	}
