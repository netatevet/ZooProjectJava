package animals;

import java.util.Random;

import diet.Omnivore;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;


/**
 *A class that represents a bear.
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 *
 */
public class Bear extends Omnivore {
	private String furColor;
	public enum Color{
		BLACK("BLACK"), WHITE("WHITE"), GRAY("GRAY");
		private String name;
		private Color(String name) {
			this.name = name;
		}
	}
	
	/**
	 * Bear's constructor.
	 * 
	 * @param name - bear's name.
	 */
	public Bear(String name) {
		super(name,new Point(100,5));
		MessageUtility.logConstractor("Bear", name);
		this.setWeight(308.2);
		this.furColor=Color.GRAY.name();
		
	}
	
	/**
	 * Bear's constructor.
	 * 
	 * @param name - bear's name.
	 * @param location - bear's 
	 */
	public Bear(String name,Point location) {
		super(name,location);
		MessageUtility.logConstractor("Bear", name);
		this.setWeight(308.2);
		this.furColor=Color.GRAY.name();
		
	}
	
	/**
	 * Bear's constructor.
	 * 
	 * @param name - bear's name.
	 * @param newcolor - bears' fur color;
	 */
	public Bear(String name, String newcolor) {
		super(name,new Point(100,5));
		MessageUtility.logConstractor("Bear", name);
		this.setWeight(308.2);
		this.setFurColor(newcolor);
	}
	
	public Bear(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
	    super(size,col,h,v,zooPanel,type);
	    this.setLocation(new Point(100,5));
	    this.setWeight(size*1.5);	   
	    this.setName("bear");
	    this.setImg();
	}
	public void setImg()
	{
		this.loadImages("bea");
	}
	
	private void roar() {
		MessageUtility.logSound(this.getName(), "Stands on its hind legs, roars and scratches its belly");
		
	}
	@Override
	public EFoodType getFoodType() {
		
		return EFoodType.MEAT;
	}
	@Override
	public void makeSound() {
		this.roar();
		
	}

	/**
	 * Bear's fur color setter.
	 * @param newcolor - the color we want to set.
	 * @return true - if the set succeed.
	 *         false - if does'nt.
	 */
	public boolean setFurColor(String newcolor) {
		boolean isSuccess = false;
		if(newcolor != "BLACK" && newcolor != "WHITE" && newcolor != "GRAY") {
			isSuccess = false;
			MessageUtility.logSetter(this.getName(), "setFurColor", newcolor, false);
			newcolor = "GRAY";
		} 
		
		this.furColor=newcolor;
		isSuccess = true;

		MessageUtility.logSetter(this.getName(), "setFurColor", newcolor, true);
		return isSuccess;
	}
		
		

}
