package animals;

import diet.Herbivore;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;


/**
 *A class that represents a giraffe.
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 *
 */
public class Giraffe extends Herbivore {
	private double neckLength;
	
	/**
	 * Giraffe's constructor.
	 * 
	 * @param name - giraffe's name.
	 */
	public Giraffe(String name) {
		super(name,new Point(50,0));
		this.setWeight(450);
		this.neckLength=1.5;
	}
	
	
	/**
	 * Giraffe's constructor.
	 * 
	 * @param name - giraffe's name.
	 * @param location giraffe's starting location.
	 */
	public Giraffe(String name,Point location) {
		super(name,location);
		MessageUtility.logConstractor("Giraffe", name);
		this.setWeight(450);
		this.neckLength=1.5;
	}
	public Giraffe(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
	    super(size,col,h,v,zooPanel,type);
	    this.setLocation(new Point(50,0));
	    this.setWeight(size*2.2);	   
	    this.setName("giraffe");
	    this.setImg();
	}
	public void setImg()
	{
		this.loadImages("grf");
	}
	
	/**
	 * Giraffe's constructor.
	 * 
	 * @param name - giraffe's name.
	 * @param neck - giraffe's neck length.
	 */
	public Giraffe(String name, double neck) {
		super(name,new Point(50,0));
		MessageUtility.logConstractor("Giraffe", name);
		this.setWeight(450);
		this.setNeckLength(neck);
	}
	public void chew() {
		MessageUtility.logSound(this.getName(), "Bleats and Stomps its legs, then chews");
	}
	@Override
	public EFoodType getFoodType() {
		
		return EFoodType.MEAT;
	}
	@Override
	public void makeSound() {
		this.chew();
		
	}

	/**
	 * Giraffe's neck length setter.
	 * 
	 * @param newlength - the new neck length.
	 * @return - true - if the set succeed.
	 *         false - if does'nt.
	 */
	public boolean setNeckLength(double newlength) {
	
		if(newlength>=1 && newlength<=2.5)
		{
			this.neckLength=newlength;
			MessageUtility.logSetter(this.getName(), "setNeckLength", newlength, true);
			return true;
		}
		MessageUtility.logSetter(this.getName(), "setNeckLength", newlength, false);
		return false;
	}

}
