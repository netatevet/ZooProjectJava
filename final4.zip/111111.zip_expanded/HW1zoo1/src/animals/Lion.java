package animals;

import java.util.Random;

import diet.Carnivore;
import diet.IDiet;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;

/**
 *A class that represents a lion.
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 *
 */
public class Lion extends Carnivore {
	private int scarCount;
	
	/**
	 * Lion's constructor.
	 * 
	 * @param name - lion's name.
	 */
	public Lion(String name) {
		super(name,new Point(20,0));
		MessageUtility.logConstractor("Lion", this.getName());
		this.setWeight(408.2);
		this.scarCount=0;
	}
	
	/**
	 * Lion's constructor.
	 * 
	 * @param name - lion's name.
	 * @param location - lion's starting location.
	 */
	public Lion(String name,Point location) {
		super(name,location);
		MessageUtility.logConstractor("Lion", this.getName());
		this.setWeight(408.2);
		this.scarCount=0;
	}
	
	public Lion(int size,String col,int h, int v,ZooPanel zooPanel,String type) {
	    super(size,col,h,v,zooPanel,type);
	    this.setLocation(new Point (20,0));
	    this.setWeight(size*0.8);
	    this.setName("lion");
	    this.setImg();
	  //  this.drawObject();
	    
	}
	
	public void setImg()
	{
		this.loadImages("lio");
	}
	
	private void roar() {
		MessageUtility.logSound(this.getName(), "Roars, then stretches and shakes its mane");
		
	}
	@Override
	public EFoodType getFoodType() {
		
		return EFoodType.NOTFOOD;
	}
	@Override
	public void makeSound() {
		this.roar();
		
	}
	@Override
	public boolean eat(IEdible food) {
		if(super.eat(food)) {
			Random rand = new Random();
			 if(rand.nextInt(2) == 0) {
				 this.scarCount = this.scarCount + 1;
			 }
			 return true;
		}

		return false;
	}
	
	

}
