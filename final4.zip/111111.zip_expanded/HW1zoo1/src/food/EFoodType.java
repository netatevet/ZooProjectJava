package food;

/**
 * Existing types of food :
 * MEAT - All animals except lions.
 * NOTFOOD - lions.
 * VEGETABLE - plants.

 * 
 * @author Rita Vinitsky
 * @see IEdible
 */
public enum EFoodType {
    MEAT,NOTFOOD,VEGETABLE;
}
