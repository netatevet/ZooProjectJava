package food;

/**
 * An interface that describes edible objects.
 * 
 *
 * @version 1.0 3 April 2022
 * @author  Rita Vinitsky
 * @see     EFoodType
 */
public interface IEdible {
	/**
	 * Recognizes what food type the object is.
	 * 
	 * @return what food type the object is - meat, vegetable or not food.
	 */
	  public EFoodType getFoodType();

}
