package utilities;

import java.util.Observable;
import java.util.Observer;

import diet.Carnivore;
import diet.Herbivore;
import diet.Omnivore;
import graphics.ZooPanel;
import plants.Cabbage;
import plants.Lettuce;
import plants.Meat;

public class Controller implements Observer,Runnable {
	
	
	
	Thread thread;
	ZooPanel zooPanel;
	
	public Controller(ZooPanel zooPanel) {
		this.thread = new Thread(this);
		this.thread.start();
		this.zooPanel = zooPanel;
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	
	while(true) {

		this.zooPanel.manageZoo();

	}
	}

}
